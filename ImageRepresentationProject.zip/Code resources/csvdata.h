/*
	The structure where data from the
	CSV files is read and stored into.
*/
struct csvdata {
	int data[128*3][128] = { 0 };
};
